package com.android;
/*
 * for usage with the third static getFood() method in the FoodFactory class
 */
public enum AnimalType {
	
	POLARBEAR,RABBIT,GOAT,ZEBRA,LION

}
