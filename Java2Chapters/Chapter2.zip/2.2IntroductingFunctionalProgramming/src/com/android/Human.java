package com.android;

public class Human implements Behaviour{

	@Override
	public void sad() {
		System.out.println("Human Sad");
		
	}

}
