package com.android;

public interface Behaviour {
	void sad();
	void mad();

}
