package com.android;

public class TestStat {
	
	public static int myInt;
	static {
		System.out.println("static initialisers called");
	}
	
	public static void statMethod() {
		
	}
	
	public void myMethod() {
		
	}

}
