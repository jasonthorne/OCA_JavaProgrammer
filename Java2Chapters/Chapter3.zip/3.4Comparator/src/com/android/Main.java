package com.android;

public class Main {
/**
 * compareTo() using compareTo() string t
 *  returns 0 if both the same
 * returns a positive 
 * @param args
 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Examples.ex1();
		//Examples.ex2();
		Examples.ex3();

	}

}
