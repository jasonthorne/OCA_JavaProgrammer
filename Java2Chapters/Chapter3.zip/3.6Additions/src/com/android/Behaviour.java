package com.android;
@FunctionalInterface
public interface Behaviour<T> {
	T get();
}
