package com.android;
@FunctionalInterface
public interface Manners<T> {

	void accept(T t);
}
