package com.android;

public class Animal {
	
	String name;
	
	Animal(String name){
		this.name=name;
	}
	
	@Override
	public String toString() {
		return "name is "+name;
	}

}
