package com.android;

public class Main {

	public static void main(String[] args) {
	//	Examples.ex1();
	//	Examples.ex2();
	//	Examples.ex3();
	//	Examples.ex4();
	//	Examples.ex5();
	//	Examples.ex6();
	//	Examples.ex7();
		Examples.ex8();

	}

}
