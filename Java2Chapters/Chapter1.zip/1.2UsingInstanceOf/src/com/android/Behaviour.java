package com.android;

public interface Behaviour {

}
