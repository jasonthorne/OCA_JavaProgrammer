package com.android;

import java.util.concurrent.SynchronousQueue;

/**
 * Coding equals, hashCode and toString()
 * @author noelf
 *
 */
public class Main {

	public static void main(String[] args) {
		//Examples.toStringEx();
		//Examples.equalsMe();
		Examples.hashMe();
	//	Examples.bitwise();
		
		
	}

}
