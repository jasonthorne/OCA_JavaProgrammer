package cat;

public class CatAdmirer {

}
