package mouse;

public class Mouse {

}
